<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.5" name="grass" tilewidth="16" tileheight="16" tilecount="128" columns="8">
 <image source="assets/grass.png" width="128" height="256"/>
</tileset>
