<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.5" name="peche" tilewidth="16" tileheight="16" tilecount="448" columns="16">
 <image source="assets/peche.png" width="263" height="461"/>
 <tile id="353">
  <animation>
   <frame tileid="353" duration="650"/>
   <frame tileid="354" duration="650"/>
   <frame tileid="355" duration="650"/>
   <frame tileid="356" duration="650"/>
  </animation>
 </tile>
</tileset>
