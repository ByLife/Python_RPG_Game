<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.5" name="mob" tilewidth="16" tileheight="16" tilecount="4189" columns="59">
 <image source="assets/mob.png" width="950" height="1136"/>
</tileset>
