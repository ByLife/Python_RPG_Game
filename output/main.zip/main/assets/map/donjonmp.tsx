<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.5" name="donjon" tilewidth="16" tileheight="16" tilecount="1024" columns="32">
 <image source="donjon.png" width="512" height="512"/>
</tileset>
