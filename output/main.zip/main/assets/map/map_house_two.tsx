<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.5" name="map_house_two" tilewidth="16" tileheight="16" tilecount="450" columns="25">
 <image source="map_house_two.png" width="400" height="288"/>
</tileset>
