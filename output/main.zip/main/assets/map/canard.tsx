<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.5" name="canard" tilewidth="16" tileheight="16" tilecount="28" columns="4">
 <image source="assets/canard.png" width="64" height="112"/>
 <tile id="0">
  <animation>
   <frame tileid="16" duration="200"/>
   <frame tileid="17" duration="200"/>
   <frame tileid="23" duration="200"/>
   <frame tileid="22" duration="200"/>
   <frame tileid="27" duration="200"/>
   <frame tileid="26" duration="200"/>
   <frame tileid="25" duration="200"/>
   <frame tileid="24" duration="200"/>
   <frame tileid="16" duration="200"/>
   <frame tileid="17" duration="200"/>
   <frame tileid="16" duration="200"/>
   <frame tileid="17" duration="200"/>
   <frame tileid="26" duration="200"/>
   <frame tileid="27" duration="200"/>
   <frame tileid="24" duration="200"/>
   <frame tileid="25" duration="200"/>
   <frame tileid="16" duration="200"/>
   <frame tileid="17" duration="200"/>
   <frame tileid="16" duration="200"/>
  </animation>
 </tile>
</tileset>
