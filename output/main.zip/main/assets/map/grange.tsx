<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.5" name="grange" tilewidth="16" tileheight="16" tilecount="84" columns="4">
 <image source="assets/grange.png" width="64" height="336"/>
</tileset>
