<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.5" name="biome_neige" tilewidth="16" tileheight="16" tilecount="527" columns="17">
 <image source="assets/biome_neige.png" width="272" height="496"/>
</tileset>
