<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.5" name="normal" tilewidth="16" tileheight="16" tilecount="1975" columns="25">
 <image source="assets/normal.png" width="400" height="1264"/>
 <tile id="637">
  <animation>
   <frame tileid="637" duration="176"/>
   <frame tileid="638" duration="176"/>
   <frame tileid="639" duration="176"/>
   <frame tileid="640" duration="176"/>
   <frame tileid="641" duration="176"/>
   <frame tileid="642" duration="176"/>
   <frame tileid="643" duration="176"/>
   <frame tileid="644" duration="176"/>
  </animation>
 </tile>
</tileset>
