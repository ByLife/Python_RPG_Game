<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.5" name="interieur_maison2" tilewidth="16" tileheight="16" tilecount="130" columns="10">
 <image source="assets/interieur_maison2.png" width="160" height="208"/>
 <tile id="31">
  <animation>
   <frame tileid="31" duration="650"/>
   <frame tileid="41" duration="650"/>
  </animation>
 </tile>
 <tile id="32">
  <animation>
   <frame tileid="32" duration="650"/>
   <frame tileid="42" duration="650"/>
  </animation>
 </tile>
 <tile id="33">
  <animation>
   <frame tileid="33" duration="650"/>
   <frame tileid="43" duration="650"/>
  </animation>
 </tile>
</tileset>
