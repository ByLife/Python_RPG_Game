<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.5" name="PC Computer - Stardew Valley - Beach Winter" tilewidth="16" tileheight="16" tilecount="527" columns="17">
 <image source="assets/PC Computer - Stardew Valley - Beach Winter.png" width="272" height="496"/>
 <tile id="0">
  <animation>
   <frame tileid="0" duration="650"/>
   <frame tileid="1" duration="650"/>
   <frame tileid="2" duration="650"/>
   <frame tileid="3" duration="650"/>
   <frame tileid="4" duration="650"/>
   <frame tileid="5" duration="650"/>
   <frame tileid="6" duration="650"/>
   <frame tileid="9" duration="650"/>
   <frame tileid="10" duration="650"/>
   <frame tileid="11" duration="650"/>
   <frame tileid="12" duration="650"/>
   <frame tileid="13" duration="650"/>
   <frame tileid="14" duration="650"/>
   <frame tileid="15" duration="650"/>
  </animation>
 </tile>
</tileset>
