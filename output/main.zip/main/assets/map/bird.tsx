<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.5" name="bird" tilewidth="16" tileheight="16" tilecount="864" columns="36">
 <image source="bird.png" width="576" height="384"/>
 <tile id="109">
  <animation>
   <frame tileid="109" duration="100"/>
   <frame tileid="112" duration="100"/>
   <frame tileid="115" duration="100"/>
  </animation>
 </tile>
 <tile id="110">
  <animation>
   <frame tileid="110" duration="100"/>
   <frame tileid="113" duration="100"/>
   <frame tileid="115" duration="100"/>
  </animation>
 </tile>
 <tile id="144">
  <animation>
   <frame tileid="144" duration="100"/>
   <frame tileid="147" duration="100"/>
   <frame tileid="150" duration="100"/>
  </animation>
 </tile>
 <tile id="145">
  <animation>
   <frame tileid="145" duration="100"/>
   <frame tileid="148" duration="100"/>
   <frame tileid="151" duration="100"/>
  </animation>
 </tile>
 <tile id="146">
  <animation>
   <frame tileid="146" duration="100"/>
   <frame tileid="149" duration="100"/>
   <frame tileid="152" duration="100"/>
  </animation>
 </tile>
 <tile id="180">
  <animation>
   <frame tileid="180" duration="100"/>
   <frame tileid="183" duration="100"/>
   <frame tileid="186" duration="100"/>
  </animation>
 </tile>
 <tile id="181">
  <animation>
   <frame tileid="181" duration="100"/>
   <frame tileid="184" duration="100"/>
   <frame tileid="187" duration="100"/>
  </animation>
 </tile>
 <tile id="182">
  <animation>
   <frame tileid="182" duration="100"/>
   <frame tileid="185" duration="100"/>
   <frame tileid="188" duration="100"/>
  </animation>
 </tile>
</tileset>
