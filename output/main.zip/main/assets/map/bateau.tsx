<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.5" name="bateau" tilewidth="16" tileheight="16" tilecount="4096" columns="128">
 <image source="assets/bateau.png" width="2048" height="512"/>
 <tile id="2109">
  <animation>
   <frame tileid="2109" duration="1000"/>
   <frame tileid="2110" duration="1000"/>
   <frame tileid="2109" duration="1000"/>
   <frame tileid="2111" duration="1000"/>
  </animation>
 </tile>
</tileset>
