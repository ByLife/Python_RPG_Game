<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.5" name="mines" tilewidth="16" tileheight="16" tilecount="720" columns="24">
 <image source="assets/mines.png" width="384" height="482"/>
</tileset>
