<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.5" name="donjon" tilewidth="16" tileheight="16" tilecount="2592" columns="48">
 <image source="assets/donjon.png" width="768" height="864"/>
</tileset>
