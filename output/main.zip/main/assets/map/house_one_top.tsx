<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.5" name="house_one_top" tilewidth="16" tileheight="16" tilecount="135" columns="15">
 <image source="house_one_top.png" width="240" height="144"/>
</tileset>
