<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.5" name="caravane" tilewidth="16" tileheight="16" tilecount="90" columns="15">
 <image source="caravane.png" width="240" height="96"/>
</tileset>
