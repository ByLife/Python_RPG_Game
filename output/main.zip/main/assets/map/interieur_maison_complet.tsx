<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.5" name="interieur_maison_complet" tilewidth="16" tileheight="16" tilecount="2176" columns="32">
 <image source="assets/interieur_maison_complet.png" width="512" height="1088"/>
</tileset>
