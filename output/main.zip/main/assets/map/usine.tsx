<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.5" name="usine" tilewidth="16" tileheight="16" tilecount="1080" columns="30">
 <image source="assets/usine.png" width="480" height="576"/>
</tileset>
