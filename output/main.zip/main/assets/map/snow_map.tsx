<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.5" name="snow_map" tilewidth="16" tileheight="16" tilecount="2500" columns="50">
 <image source="snow_map.png" width="800" height="800"/>
</tileset>
