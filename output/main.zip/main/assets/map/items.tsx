<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.5" name="items" tilewidth="16" tileheight="16" tilecount="130" columns="10">
 <image source="assets/items.png" width="160" height="220"/>
</tileset>
