<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.5" name="automne" tilewidth="16" tileheight="16" tilecount="1975" columns="25">
 <image source="assets/automne.png" width="400" height="1264"/>
 <tile id="1225">
  <animation>
   <frame tileid="1225" duration="100"/>
   <frame tileid="1226" duration="100"/>
   <frame tileid="1250" duration="100"/>
   <frame tileid="1251" duration="100"/>
   <frame tileid="1275" duration="100"/>
   <frame tileid="1276" duration="100"/>
  </animation>
 </tile>
</tileset>
