<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.5" name="snow3" tilewidth="16" tileheight="16" tilecount="1980" columns="44">
 <image source="assets/snow3.png" width="710" height="720"/>
</tileset>
