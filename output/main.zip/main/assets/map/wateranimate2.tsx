<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.5" name="wateranimate2" tilewidth="16" tileheight="16" tilecount="864" columns="36">
 <image source="../../../../Downloads/wateranimate2.png" width="576" height="386"/>
</tileset>
