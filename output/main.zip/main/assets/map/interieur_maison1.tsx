<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.5" name="interieur_maison1" tilewidth="16" tileheight="16" tilecount="240" columns="12">
 <image source="assets/interieur_maison1.png" width="192" height="320"/>
</tileset>
