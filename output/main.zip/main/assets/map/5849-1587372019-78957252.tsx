<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.5" name="5849-1587372019-78957252" tilewidth="32" tileheight="32" tilecount="644" columns="23">
 <image source="../../../../Downloads/5849-1587372019-78957252.gif" width="765" height="919"/>
</tileset>
